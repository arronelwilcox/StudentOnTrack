package Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import DAO.AssessmentDAO;
import DAO.CourseDAO;
import DAO.TermDAO;
import DAO.UserDAO;
import Entity.Assessment;
import Entity.Course;
import Entity.Term;
import Entity.User;

@Database(entities = {Term.class , Course.class, Assessment.class, User.class}, version = 25, exportSchema = false)
public abstract class StudentDatabaseBuilder extends RoomDatabase {
    abstract public TermDAO termDAO();
    abstract public CourseDAO courseDAO();
    abstract public AssessmentDAO assessmentDAO();
    abstract public UserDAO userDAO();

    private static volatile StudentDatabaseBuilder INSTANCE ;

    static StudentDatabaseBuilder getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (StudentDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), StudentDatabaseBuilder.class,
                            "studentDatabase").fallbackToDestructiveMigration().build();
                }
            }
        }
        return INSTANCE;
    }
}
