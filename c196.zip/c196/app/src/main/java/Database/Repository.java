package Database;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import DAO.AssessmentDAO;
import DAO.CourseDAO;
import DAO.TermDAO;
import DAO.UserDAO;
import Entity.Assessment;
import Entity.Course;
import Entity.Term;
import Entity.User;

public class Repository {
    private TermDAO termDAO;
    private CourseDAO courseDAO;
    private AssessmentDAO assessmentDAO;
    private UserDAO userDAO;
    private List<Term> allTerms;
    private List<Course> allCourse;
    private List<Assessment> allAssessments;
    private List<User> allUser;



    private static int NUMBER_OF_THREADS = 4;
    static  final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(Application application){
        StudentDatabaseBuilder db = StudentDatabaseBuilder.getDatabase(application);
        termDAO = db.termDAO();
        courseDAO = db.courseDAO();
        assessmentDAO =db.assessmentDAO();
        userDAO = db.userDAO();

    }

    /**
     * Lambda Expression which creates a separate thread to asynchronously build the Term table
     * in the database as the program executes other functions.
     * @param term
     */
    public void insertTerm(Term term){
        databaseExecutor.execute(()->{
            termDAO.insert(term);
        });
        try{
            Thread.sleep(250);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    /**
     * Lambda Expression which creates a separate thread to asynchronously build the Course table
     * in the database as the program executes other functions.
     * @param course
     */
    public void insertCourse(Course course){
        databaseExecutor.execute(()->{
            courseDAO.insert(course);
        });
        try{
            Thread.sleep(250);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Lambda Expression which creates a separate thread to asynchronously build the Assessment table
     * in the database as the program executes other functions.
     * @param assessment
     */
    public void insertAssessment(Assessment assessment){
        databaseExecutor.execute(()->{
            assessmentDAO.insert(assessment);
        });
        try{
            Thread.sleep(250);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    /**
     * Lambda Expression which creates a separate thread to asynchronously build the User table
     * in the database as the program executes other functions.
     * @param user
     */
    public void insertUser(User user){
        databaseExecutor.execute(()->{
            userDAO.insert(user);
        });
        try{
            Thread.sleep(250);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    /**
     * This queries the database for the entire list of Terms available.
     * @param
     * @return
     */
    public List<Term> getAllTerms(){
        databaseExecutor.execute(()->{
            allTerms = termDAO.getAllTerms();
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        return allTerms;
    }


    /**
     * This queries the database for all the Courses available.
     * @param
     * @return
     */
    public List<Course> getAllCourse(){
        databaseExecutor.execute(()->{
            allCourse = courseDAO.getAllCourses();
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        return allCourse;
    }
    /**
     * This queries the database for all the Assessment available.
     * @return
     */
    public List<Assessment> getAllAssessments(){
        databaseExecutor.execute(()->{
            allAssessments = assessmentDAO.getAllAssessments();
            });
        try{
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        return allAssessments;
    }
//    /**
//     * This queries the database for all the Courses available.
//     * @param
//     * @return
//     */
//    public List<User> getAllUsers(){
//        databaseExecutor.execute(()->{
//            allUser = userDAO.getAllUsers();
//        });
//        try{
//            Thread.sleep(1000);
//        }catch(InterruptedException e){
//            e.printStackTrace();
//        }
//        return allUser;
//    }
    /**
     * This function collects all the Assessments associated with a specific course and generates a
     * list of all the assessments pertaining to that course.
     * @param course
     * @return
     */
    public List<Assessment> getAssocAssessments(Course course){
        databaseExecutor.execute(()->{
            allAssessments = assessmentDAO.getAllAssessments();
            for (Assessment currentAssessment:allAssessments) {
                if(currentAssessment.getAssessmentCourseID() == course.getCourseID()){
                    allAssessments = getAssocAssessments(course);
                }
                else {
                    System.out.println("Associated Courses not loaded or apparent");
                    return;
                }
            }
        });
        try{
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        return allAssessments;
    }


    /**
     * This function collects all the courses associated with a specific Term and generates a
     * list of all the Courses pertaining to that Term.
     * @param term
     * @return
     */
    public List<Course> getAssocCourses(Term term) {
        databaseExecutor.execute(() -> {
            allCourse = courseDAO.getAllCourses();
            for (Course currentCourse : allCourse) {
                if (currentCourse.getCourseTermID() == term.getTermID()) {
                    allCourse = getAssocCourses(term);
                } else {
                    System.out.println("Associated Terms not loaded or apparent");
                    return;
                }
            }
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allCourse;
    }


    public void updateTerm(Term term) {
        databaseExecutor.execute(()->{
            termDAO.update(term);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    public void updateCourse(Course course) {
        databaseExecutor.execute(()->{
            courseDAO.update(course);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    public void updateAssessment(Assessment assessment) {
        databaseExecutor.execute(()->{
            assessmentDAO.update(assessment);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    public void deleteTerm(Term term){
        databaseExecutor.execute(()->{
            termDAO.delete(term);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    public void deleteCourse(Course course){
        databaseExecutor.execute(()->{
            courseDAO.delete(course);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    public void deleteAssessment(Assessment assessment){
        databaseExecutor.execute(()->{
            assessmentDAO.delete(assessment);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    public void deleteUser(User user){
        databaseExecutor.execute(()->{
            userDAO.delete(user);
        });
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
