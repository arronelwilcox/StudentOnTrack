package Entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.ArrayList;

@Entity(tableName = "assessmentTable")
public class Assessment {
    //private ArrayList <Assessment> assessmentList;

    @PrimaryKey(autoGenerate = true)
    private int assessmentID;

    private String assessment_title, type;
    private String assessment_start_date,assessment_end_date;
    private int assessmentCourseID;

//    private ArrayList<Assessment> assessmentList=null;

    public Assessment(int assessmentID,String assessment_title, String type,String assessment_start_date, String assessment_end_date,int assessmentCourseID) {
        this.assessmentID = assessmentID;
        this.assessment_title = assessment_title;
        this.type = type;
        this.assessment_start_date = assessment_start_date;
        this.assessment_end_date = assessment_end_date;
        this.assessmentCourseID = assessmentCourseID;
    }

    public String getAssessment_title() {
        return assessment_title;
    }

    public void setAssessment_title(String assessment_title) {
        this.assessment_title = assessment_title;
    }
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAssessment_end_date() {
        return assessment_end_date;
    }

    public String getAssessment_start_date() {
        return assessment_start_date;
    }

    public void setAssessment_start_date(String assessment_start_date) {
        this.assessment_start_date = assessment_start_date;
    }

    public void setAssessment_end_date(String assessment_end_date) {
        this.assessment_end_date = assessment_end_date;
    }

    public void setAssessmentList(ArrayList<Assessment> assessmentList) {
        assessmentList = assessmentList;
    }

    public int getAssessmentCourseID() {
        return assessmentCourseID;
    }

    public void setAssessmentCourseID(int assessmentCourseID) {
        this.assessmentCourseID = assessmentCourseID;
    }

    public int getAssessmentID() {
        return assessmentID;
    }

    public void setAssessmentID(int assessmentID) {
        this.assessmentID = assessmentID;
    }

    @Override
    public String toString() {
        return "Assessment{" +
                ", assessmentID=" + assessmentID +
                ", assessment_title='" + assessment_title + '\'' +
                ", type='" + type + '\'' +
                ", assessment_start_date=" + assessment_start_date +
                ", assessment_end_date=" + assessment_end_date +
                ", courseID=" + assessmentCourseID +
                '}';
    }
}
