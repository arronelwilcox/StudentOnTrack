package UI;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;

import com.example.c196.R;


public class UserLogin extends Activity {
    EditText username;
    EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_log_in);
        username = findViewById(R.id.editUsername);
        password = findViewById(R.id.editPassword);
    }
    public void EnterMain(View view) {
        Intent intent = new Intent(UserLogin.this, MainActivity.class);
        startActivity(intent);
    }
    public void alert(String alertMessage){
        AlertDialog.Builder builder = new AlertDialog.Builder(UserLogin.this);
        builder.setMessage(alertMessage);
        // Set Alert Title
        builder.setTitle("Alert !");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
                //finish();
            }
        });
        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();
        // return;
    }

    public void login(View view) {
        if(username.getText().toString().equals("test") && password.getText().toString().equals("test") ||
                username.getText().toString().equals("admin") && password.getText().toString().equals("admin")){
            EnterMain(view);
        }
        else{
            String alert = "The Log in credentials are incorrect. Please try again." ;
            alert(alert);
        }
    }
}
