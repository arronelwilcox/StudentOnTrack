package UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import com.example.c196.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import Database.Repository;
import Entity.Assessment;
import Entity.Course;
import Entity.Term;


public class AssessmentDetail extends AppCompatActivity {
    EditText editName;
    EditText editID;
    Spinner editCID;
    EditText editStart;
    EditText editDue;

    Spinner editType;
    int aID,cID;
    String name,dueDate,startDate,type;
    ArrayAdapter<CharSequence>typeAdapter;
    String myFormat = ("MM/dd/yy");
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
    DatePickerDialog.OnDateSetListener due,start;
    Calendar myCalendarStart = Calendar.getInstance();
    Calendar myCalendarEnd = Calendar.getInstance();


    Repository repo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_detail);
        repo = new Repository(getApplication());
        editID = findViewById(R.id.assessmentID);
        editName = findViewById(R.id.assessmentName);
        editCID = findViewById(R.id.courseID);
        editStart = findViewById(R.id.assessmentStartDate);
        editDue = findViewById(R.id.assessmentDueDate);
        editType = findViewById(R.id.assessmentType);
        int nextAssessmentID = repo.getAllAssessments().get(repo.getAllAssessments().size()-1).getAssessmentID()+1;

        aID = getIntent().getIntExtra("Assessment ID",nextAssessmentID);
        cID = getIntent().getIntExtra("Assessment Course ID",-1);
        name = getIntent().getStringExtra("Assessment Title");
        startDate = getIntent().getStringExtra("Assessment Start Date");
        dueDate = getIntent().getStringExtra("Assessment Due Date");
        type = getIntent().getStringExtra("Assessment Type");
        editID.setText(String.valueOf(aID));
        ArrayList<Course> termArrayList = new ArrayList<>();
        termArrayList.addAll(repo.getAllCourse());
        ArrayList<Integer>termIdList = new ArrayList<>();
        for(Course term: termArrayList){
            termIdList.add(term.getCourseID());
        }
        ArrayAdapter<Integer> termIdAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,termIdList);
        termIdAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        editCID.setAdapter(termIdAdapter);
        editCID.setSelection(cID-1);

        editName.setText(name);
        editStart.setText(startDate);
        editDue.setText(dueDate);
        editStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = editStart.getText().toString();
                if(info.equals(""))info="08/18/22";
                try {
                    myCalendarStart.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(AssessmentDetail.this,start,myCalendarStart.get(Calendar.YEAR),
                        myCalendarStart.get(Calendar.MONTH),myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        editDue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = editDue.getText().toString();
                if(info.equals(""))info="08/18/22";
                try {
                    myCalendarEnd.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(AssessmentDetail.this,due,myCalendarEnd.get(Calendar.YEAR),
                        myCalendarEnd.get(Calendar.MONTH),myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        typeAdapter  = ArrayAdapter.createFromResource(this,R.array.assessment_array, android.R.layout.simple_spinner_item);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        editType.setAdapter(typeAdapter);
        int spinnerPosition = typeAdapter.getPosition(type);
        editType.setSelection(spinnerPosition);
        start = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarEnd.set(Calendar.YEAR,year);
                myCalendarEnd.set(Calendar.MONTH,monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabelStart();
            }
        };
        due = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR,year);
                myCalendarStart.set(Calendar.MONTH,monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabelDue();
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.assessment_detail,menu);
        return true;
    }

    @Override
    public  boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        else if (item.getItemId() == R.id.notifyS) {
            String sDateFormat = editStart.getText().toString();
            Date sDate = null;
            try {
                sDate = sdf.parse(sDateFormat);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Long sTrigger = sDate.getTime();

            if (name == null){
                editName.clearFocus();
                name = editName.getText().toString();
            }
            Intent sIntent = new Intent(AssessmentDetail.this, MyReceiver.class);
            sIntent.putExtra("key","Your Assessment "+ name + " starts today");
            PendingIntent senderStart = PendingIntent.getBroadcast(AssessmentDetail.this,MainActivity.numAlert++,sIntent,PendingIntent.FLAG_IMMUTABLE);

            AlarmManager alarmManagerS = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManagerS.set(AlarmManager.RTC_WAKEUP,sTrigger,senderStart);

            return true;
        }
        else if (item.getItemId() == R.id.notifyE) {
            String sDateFormat = editDue.getText().toString();
            Date sDate = null;
            try {
                sDate = sdf.parse(sDateFormat);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Long sTrigger = sDate.getTime();

            if (name == null){
                editName.clearFocus();
                name = editName.getText().toString();
            }
            Intent sIntent = new Intent(AssessmentDetail.this, MyReceiver.class);
            sIntent.putExtra("key","Your Assessment "+ name + " is due today");
            PendingIntent senderStart = PendingIntent.getBroadcast(AssessmentDetail.this,MainActivity.numAlert++,sIntent,PendingIntent.FLAG_IMMUTABLE);

            AlarmManager alarmManagerS = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManagerS.set(AlarmManager.RTC_WAKEUP,sTrigger,senderStart);

            return true;
        }

            return super.onOptionsItemSelected(item);


    }

    public void EnterAssessmentList(View view) {
        Intent intent = new Intent(AssessmentDetail.this,AssessmentList.class);
        startActivity(intent);
    }
    private void updateLabelDue(){
        editDue.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelStart(){
        editStart.setText(sdf.format(myCalendarEnd.getTime()));
    }
    public void saveButtonAssessment(View view) {
        Assessment assessment;
        int nextAssessmentID = repo.getAllAssessments().get(repo.getAllAssessments().size()-1).getAssessmentID()+1;
        if(aID == nextAssessmentID){
            assessment = new Assessment(nextAssessmentID,editName.getText().toString(),
                    editType.getSelectedItem().toString(),editStart.getText().toString()
                    ,editDue.getText().toString(),editCID.getSelectedItemPosition()+1);
            repo.insertAssessment(assessment);
        }
        else{
            assessment = new Assessment(aID,editName.getText().toString(),
                    editType.getSelectedItem().toString(),editStart.getText().toString(),
                    editDue.getText().toString(),editCID.getSelectedItemPosition()+1);
            repo.updateAssessment(assessment);
        }
        EnterAssessmentList(view);
    }

    public void deleteButtonAssessment(View view) {
        Assessment assessment;
        int newID = Integer.parseInt(editID.getText().toString());
        if(aID == -1){
            //repo.getAllAssessments().get(repo.getAllAssessments().size()-1).getAssessmentID()+1;
            assessment = new Assessment(newID,editName.getText().toString(),
                    editType.getSelectedItem().toString(),editStart.getText().toString(),
                    editDue.getText().toString() ,editCID.getSelectedItemPosition()+1);
        }
        else {
            assessment = new Assessment(newID,editName.getText().toString(),
                    editType.getSelectedItem().toString(),editStart.getText().toString(),
                    editDue.getText().toString() ,editCID.getSelectedItemPosition()+1);
        }
        repo.deleteAssessment(assessment);
        EnterAssessmentList(view);
    }
}