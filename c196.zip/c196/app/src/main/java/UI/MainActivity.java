package UI;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Database;

import com.example.c196.R;

import java.util.ArrayList;
import java.util.List;

import Database.Repository;
import Entity.Assessment;
import Entity.Course;
import Entity.Term;
import Entity.User;

public class MainActivity extends AppCompatActivity {

    public static int numAlert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buildUser();
    }
    public List<Assessment> assessmentPerformance(List<Assessment> performanceList){
        List<Assessment> newList = new ArrayList<>();
        for(Assessment assessment:performanceList){
            if(assessment.getType().equals("PA")){
                newList.add(assessment);
            }
            else{
                continue;
            }
        }
        return newList;
    }
    public List<Assessment> assessmentObjective(List<Assessment> objectiveList){
        List<Assessment> newList = new ArrayList<>();
        for(Assessment assessment:objectiveList){
            if(assessment.getType().equals("OA")){
                newList.add(assessment);
            }
            else{
                continue;
            }
        }
        return newList;
    }
    public void alertReport(View view){
        Repository repository = new Repository(getApplication());
        String termInfo = "Currently there are "+ repository.getAllTerms().size() + " total terms available for the student to register in.\n";
        String courseInfo = "The student is registered for "+ repository.getAllCourse().size() +" Courses total .\n";
        String assessmentInfo = "The student must complete "+ repository.getAllAssessments().size()+" Assessments in total so far.\n";
        String filler = "###############################\n";
        String assessmentTypes = ("Currently out of the assessments, "+ assessmentPerformance(repository.getAllAssessments()).size() +
                " are Performance Assessments and "+ assessmentObjective(repository.getAllAssessments()).size()+
                " are Objective assessments");
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(termInfo + filler +courseInfo + filler + assessmentInfo + filler + assessmentTypes);
        // Set Alert Title
        builder.setTitle("Student Quantity Report");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
                //finish();
            }
        });
        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();
        // return;
    }
    public void EnterTermList(View view) {
        Intent intent = new Intent(MainActivity.this, TermList.class);
        startActivity(intent);
    }
    public void buildTerm(){
        Repository repo = new Repository(getApplication());
        Term term1 = new Term(1, "Fall Term", "08/01/22", "11/01/22");
        Term term2 = new Term(2, "Winter Term", "11/01/22", "02/01/23");
        Term term3 = new Term(3, "Spring Term", "02/01/23", "06/01/23");
        Term term4 = new Term(4, "Summer Term", "06/01/23", "08/01/23");
        repo.insertTerm(term1);
        repo.insertTerm(term2);
        repo.insertTerm(term3);
        repo.insertTerm(term4);
    }
    public void buildCourse(){
        Repository repo = new Repository(getApplication());
        Course course1 = new Course(1,"Software Engineering",
                "Complete","Programming 101","Professor Pedro","ppedro@school.edu",
                1111111111, 1,"11/11/22","12/12/22");
        Course course2 = new Course(2,"Biology","Complete",
                "Biology 101","Professor Chuck","pchuck@school.edu",
                1112221111, 2,"11/11/22","12/12/22");
        Course course3 = new Course(3,"Chemistry",
                "Progress","Chemistry 101","Professor Billy","pbilly@school.edu",
                1112223333, 3,"11/11/22","12/12/22");
        Course course4 = new Course(4,"Physics",
                "Progress","Physics 101","Professor Dawn","pdawn@school.edu",
                1112223333, 4,"11/11/22","12/12/22");
        repo.insertCourse(course1);
        repo.insertCourse(course2);
        repo.insertCourse(course3);
        repo.insertCourse(course4);
    }

    public void buildAssessment(){
        Repository repo = new Repository(getApplication());
        Assessment assessment1 = new Assessment(1,"Software Assessment",
                "PA","10/11/2022","11/11/2022",1);
        Assessment assessment2 = new Assessment(2,"Biology Assessment",
                "OA","10/11/2022","11/11/2022",2);
        Assessment assessment3 = new Assessment(3,"Chemistry Assessment",
                "PA","10/11/2022","11/11/2022",3);
        Assessment assessment4 = new Assessment(4,"Physics Assessment",
                "OA","10/11/2022","11/11/2022",4);
        repo.insertAssessment(assessment1);
        repo.insertAssessment(assessment2);
        repo.insertAssessment(assessment3);
        repo.insertAssessment(assessment4);
    }

    public void buildUser(){
        Repository repo = new Repository(getApplication());
        User user1 = new User("admin","admin");
        User user2 = new User("test","test");
        repo.insertUser(user1);
        repo.insertUser(user2);
        buildTerm();
        buildCourse();
        buildAssessment();
    }
    public void EnterCourseList(View view) {
        Intent intent = new Intent(MainActivity.this, CourseList.class);
        startActivity(intent);
    }

    public void EnterAssessmentList(View view) {
        Intent intent = new Intent(MainActivity.this, AssessmentList.class);
        startActivity(intent);
    }

}