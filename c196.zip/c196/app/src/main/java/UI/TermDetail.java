package UI;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import Database.Repository;
import Entity.Course;
import Entity.Term;

public class TermDetail extends AppCompatActivity {
    EditText editName;
    EditText editID;
    EditText editStart;
    EditText editEnd;
    String name;
    int id;
    Calendar myCalendarStart = Calendar.getInstance();
    Calendar myCalendarEnd = Calendar.getInstance();
    String start,end;
    Repository repo;
    String myFormat = ("MM/dd/yy");
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
    DatePickerDialog.OnDateSetListener startDate,endDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new Repository(getApplication());
        // Acquire a list of all terms
        List<Term>termList = repo.getAllTerms();
        // This variable stores the next Term ID
        // used for auto population.
        int nextTermID = termList.get(termList.size()-1).getTermID()+1;
        setContentView(R.layout.activity_term_detail);
        editID = findViewById(R.id.termID);
        editName = findViewById(R.id.termName);
        editStart = findViewById(R.id.termStart);
        editEnd = findViewById(R.id.termEnd);
        id = getIntent().getIntExtra("termID",nextTermID);
        name = getIntent().getStringExtra("termTitle");
        start = getIntent().getStringExtra("termStart");
        end = getIntent().getStringExtra("termEnd");
        editStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = editStart.getText().toString();
                if(info.equals(""))info="08/29/22";
                try {
                    myCalendarStart.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(TermDetail.this,startDate,myCalendarStart.get(Calendar.YEAR),
                        myCalendarStart.get(Calendar.MONTH),myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        editEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String info = editEnd.getText().toString();
                if(info.equals(""))info="09/20/22";
                try {
                    myCalendarEnd.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(TermDetail.this,endDate,myCalendarEnd.get(Calendar.YEAR),
                        myCalendarEnd.get(Calendar.MONTH),myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        // This Section of code sets the assocciated Course list in the term detail view.
        final CourseAdapter courseAdapter = new CourseAdapter(this);
        RecyclerView recyclerView = findViewById(R.id.termDetailRec);
        recyclerView.setAdapter(courseAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Course> courseList = new ArrayList<>();
        List<Course> main_courseList = repo.getAllCourse();

        //repo = new Repository(getApplication());
        int size = repo.getAllCourse().size();
        for(int i = 0;i < size;i++){
            if(main_courseList.get(i).getCourseTermID() == id){
                courseList.add(main_courseList.get(i));
            }
            courseAdapter.setCourseItems(courseList);
        }
        String idText = String.valueOf(id);
        editID.setText(idText);
        editName.setText(name);
        editStart.setText(start);
        editEnd.setText(end);
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR,year);
                myCalendarStart.set(Calendar.MONTH,monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabelStart();
            }
        };
        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                myCalendarEnd.set(Calendar.YEAR,i);
                myCalendarEnd.set(Calendar.MONTH,i1);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH,i2);
                updateLabelEnd();
            }
        };
    }

    private void updateLabelStart(){
        editStart.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd(){
        editEnd.setText(sdf.format(myCalendarEnd.getTime()));
    }
    public void EnterTermList(View view) {
        Intent intent = new Intent(TermDetail.this,TermList.class);
        startActivity(intent);
    }
    public void saveButton(View view) {
        Term term;
        if(id < 1 || id > repo.getAllTerms().get(repo.getAllTerms().size()-1).getTermID()){
            int newID = repo.getAllTerms().get(repo.getAllTerms().size()-1).getTermID()+1;
            term = new Term(newID,editName.getText().toString(),editStart.getText().toString(),editEnd.getText().toString());
            repo.insertTerm(term);
        }
        else{
            term = new Term(id,editName.getText().toString(),editStart.getText().toString(),editEnd.getText().toString());
            repo.updateTerm(term);
        }
        EnterTermList(view);
    }

    public void deleteTerm(View view) {
        Term term = new Term(id,editName.getText().toString(),
                editStart.getText().toString(),editEnd.getText().toString());
        List<Course> courseList = repo.getAllCourse();
        for (Course course: courseList) {
            if (id == course.getCourseTermID()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TermDetail.this);
                builder.setMessage("Sorry you cant delete. This Term has Course/Courses Assigned to it\n"+
                        "Please delete the course: "+ course.getCourse_title()+" before deleting this Term");
                // Set Alert Title
                builder.setTitle("Alert !");
                builder.setCancelable(false);
                builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });

                // Create the Alert dialog
                AlertDialog alertDialog = builder.create();
                // Show the Alert Dialog box
                alertDialog.show();
                return;
            }
            else{
                repo.deleteTerm(term);
                EnterTermList(view);
            }
        }
    }

}