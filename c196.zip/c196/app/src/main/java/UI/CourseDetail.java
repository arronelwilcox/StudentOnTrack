package UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.c196.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Locale;
import java.util.Stack;

import Database.Repository;
import Entity.Course;
import Entity.Term;

public class CourseDetail extends AppCompatActivity {

    EditText editName;
    EditText editID;
    Spinner editStatus;
    EditText editIns;
    EditText editEmail;
    EditText editPhone;
    Spinner editTermID;
    EditText editNotes;
    EditText editStart;
    EditText editEnd;
    String myFormat = ("MM/dd/yy");
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
    DatePickerDialog.OnDateSetListener startDate,endDate;
    String cName,iName,notes;
    int id,tID;
    String status,email,start,end;
    Long phone;
    Repository repo ;
    Calendar myCalendarStart = Calendar.getInstance();
    Calendar myCalendarEnd = Calendar.getInstance();
    ArrayAdapter<CharSequence>statusAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new Repository(getApplication());
        setContentView(R.layout.activity_course_detail);
        List<Term>termList = repo.getAllTerms();
        List<Course>courseList = repo.getAllCourse();
        int nextCourseID = courseList.get(courseList.size()-1).getCourseID()+1;
        editID = findViewById(R.id.courseID);
        editName = findViewById(R.id.courseName);
        editStatus = findViewById(R.id.courseStatus);
        editIns = findViewById(R.id.courseInsName);
        editEmail = findViewById(R.id.courseEmail);
        editPhone = findViewById(R.id.courseInsPhone);
        editTermID = findViewById(R.id.courseID2);
        editNotes = findViewById(R.id.courseNotes);
        editStart = findViewById(R.id.editStart);
        editEnd = findViewById(R.id.editEnd);

        editStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = editStart.getText().toString();
                if(info.equals(""))info="08/18/22";
                try {
                    myCalendarStart.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(CourseDetail.this,startDate,myCalendarStart.get(Calendar.YEAR),
                        myCalendarStart.get(Calendar.MONTH),myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        editEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String info = editEnd.getText().toString();
                if(info.equals(""))info="09/20/22";
                try {
                    myCalendarEnd.setTime(sdf.parse(info));
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(CourseDetail.this,endDate,myCalendarEnd.get(Calendar.YEAR),
                        myCalendarEnd.get(Calendar.MONTH),myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        id = getIntent().getIntExtra("Course ID",nextCourseID);
        cName = getIntent().getStringExtra("Course Title");
        status = getIntent().getStringExtra("Course Status");
        notes = getIntent().getStringExtra("Course Notes");
        iName = getIntent().getStringExtra("Course Instructor Name");
        email = getIntent().getStringExtra("Course Instructor email");
        phone = getIntent().getLongExtra("Course Instructor phone",1);
        tID = getIntent().getIntExtra("Associated Term ID",-1);
        start = getIntent().getStringExtra("Start Date");
        end = getIntent().getStringExtra("End Date");
        String cid = String.valueOf(id);
        editID.setText(cid);
        editName.setText(cName);
        editNotes.setText(notes);
        // This section of code sets the dropdown spinner for course associated Term ID options
        ArrayList<Term> termArrayList = new ArrayList<>();
        termArrayList.addAll(termList);
        ArrayList<Integer>termIdList = new ArrayList<>();
        for(Term term: termArrayList){
            termIdList.add(term.getTermID());
        }
        ArrayAdapter<Integer> termIdAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,termIdList);
        termIdAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        editTermID.setAdapter(termIdAdapter);
        editTermID.setSelection(tID-1);

        // This section of code sets the dropdown spinner for course status options
        statusAdapter  = ArrayAdapter.createFromResource(this,R.array.status_array, android.R.layout.simple_spinner_item);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        editStatus.setAdapter(statusAdapter);
        int spinnerPosition = statusAdapter.getPosition(status);
        editStatus.setSelection(spinnerPosition);

        editStart.setText(start);
        editEnd.setText(end);
        editIns.setText(iName);
        editEmail.setText(email);
        String phoneT = String.valueOf(phone);
        editPhone.setText((phoneT));
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                myCalendarStart.set(Calendar.YEAR,year);
                myCalendarStart.set(Calendar.MONTH,monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabelStart();
            }
        };
        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                myCalendarEnd.set(Calendar.YEAR,i);
                myCalendarEnd.set(Calendar.MONTH,i1);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH,i2);
                updateLabelEnd();
            }
        };
    }

    public void EnterCourseList(View view) {
        Intent intent = new Intent(CourseDetail.this,CourseList.class);
        startActivity(intent);
    }
    private void updateLabelStart(){
        editStart.setText(sdf.format(myCalendarStart.getTime()));
    }
    private void updateLabelEnd(){
        editEnd.setText(sdf.format(myCalendarEnd.getTime()));
    }

    public void saveButtonCourse(View view) {
        Course course;
        int newID,termID;
        String myStatus;
        long phoneConv;
        repo = new Repository(getApplication());
        List<Course>courseList = repo.getAllCourse();
        int nextCourseID = courseList.get(courseList.size()-1).getCourseID()+1;
        //This will happen if a new course is being added.
        if (editStart.getText().toString().trim().equals(editEnd.getText().toString().trim()) ) {
            String error = ("Something is wrong with the Date fields. Please make Sure the Start " +
                    "and End Dates are different");
            alert(error);
            return;
        }
        if(id == nextCourseID){
            updateLabelStart();
            updateLabelEnd();
            start = editStart.getText().toString().trim();
            end = editEnd.getText().toString().trim();
            phoneConv = (Long.parseLong(editPhone.getText().toString()));
            myStatus = editStatus.getSelectedItem().toString();
            newID = Integer.parseInt(editID.getText().toString());
            termID = editTermID.getSelectedItemPosition()+1;
            course = new Course(newID,editName.getText().toString(), myStatus,
                    editNotes.getText().toString(),editIns.getText().toString()
            ,editEmail.getText().toString(),phoneConv,termID,editStart.getText().toString()
                    ,editEnd.getText().toString());
            repo.insertCourse(course);
        }
        // This will happen if its the first course
        else if(repo.getAllCourse().size() == 0){
            newID = 1;
            phoneConv = (Long.parseLong(editPhone.getText().toString()));
            myStatus = editStatus.getSelectedItem().toString().trim();
            termID = editTermID.getSelectedItemPosition();
            course = new Course(newID,editName.getText().toString(), myStatus,
                    editNotes.getText().toString(),editIns.getText().toString()
                    ,editEmail.getText().toString(),phoneConv,termID,editStart.getText().toString().trim()
                    ,editEnd.getText().toString().trim());

            repo.insertCourse(course);
        }
        //This will happen if a course is being updated.
        else{
            phoneConv = (Long.parseLong(editPhone.getText().toString()));
            myStatus = editStatus.getSelectedItem().toString();
            course = new Course(id,editName.getText().toString(), myStatus,
                    editNotes.getText().toString(),editIns.getText().toString()
                    ,editEmail.getText().toString(),phoneConv,editTermID.getSelectedItemPosition()+1
                    ,editStart.getText().toString().trim(),
                    editEnd.getText().toString().trim());
            repo.updateCourse(course);
        }
        EnterCourseList(view);
    }

    public void alert(String alertMessage){
        AlertDialog.Builder builder = new AlertDialog.Builder(CourseDetail.this);
        builder.setMessage(alertMessage);
        // Set Alert Title
        builder.setTitle("Alert !");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
                //finish();
            }
        });
        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();
       // return;
    }

    public void deleteButtonCourse(View view){
        Course course;
        long phoneConv = (Long.parseLong(editPhone.getText().toString()));

        course = new Course(id, editName.getText().toString(), editStatus.getSelectedItem().toString(),
                editNotes.getText().toString(),editIns.getText().toString()
                , editEmail.getText().toString(),phoneConv, tID
                ,editStart.getText().toString(),editEnd.getText().toString());
        repo.deleteCourse(course);
        EnterCourseList(view);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.course_detail,menu);
        return true;
    }
    @Override
    public  boolean onOptionsItemSelected(MenuItem item) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YY");
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        else if (item.getItemId() == R.id.share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Here are the notes for course "+ cName+" : "+ notes);
            sendIntent.putExtra(Intent.EXTRA_TIME, "Course Notes");
            sendIntent.setType("text/plain");
            Intent shareIntent = Intent.createChooser(sendIntent, null);
            startActivity(shareIntent);
            return true;
        }
        else if (item.getItemId() == R.id.notifyStart) {
            String sDateFormat = editStart.getText().toString().trim();
            String eDateFormat = editEnd.getText().toString().trim();
            if (sDateFormat.equals(eDateFormat) ) {
                String error = ("Something is wrong with the Date Notifications. Please make Sure the Start " +
                        "and End Dates are different");
                alert(error);
                return true;
            }
            Date sDate = null;
            try {
                sDate = sdf.parse(sDateFormat);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            Long sTrigger = sDate.getTime();
            ZoneId defaultZoneId = ZoneId.systemDefault();
            //Converting the date to Instant
            Instant instantS = sDate.toInstant();
            LocalDate localDateS = instantS.atZone(defaultZoneId).toLocalDate();
            String s = formatter.format(localDateS);
            if (cName == null) {
                editName.clearFocus();
                cName = editName.getText().toString();
            }
            Intent sIntent = new Intent(CourseDetail.this, MyReceiver.class);
            sIntent.putExtra("key", "Your course " + cName + " starts "+ s);
            PendingIntent senderStart = PendingIntent.getBroadcast(CourseDetail.this, MainActivity.numAlert++, sIntent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManagerS = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManagerS.set(AlarmManager.RTC_WAKEUP, sTrigger, senderStart);
            return true;
        }
        else if (item.getItemId() == R.id.notifyEnd) {
            String sDateFormat = editStart.getText().toString().trim();
            String eDateFormat = editEnd.getText().toString().trim();
            if (sDateFormat.equals(eDateFormat) ) {
                String error = ("Something is wrong with the Date Notifications. Please make Sure the Start " +
                        "and End Dates are different");
                alert(error);
                return true;
            }
            Date eDate = null;
            try {
                eDate = sdf.parse(eDateFormat);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            Long eTrigger = eDate.getTime();
            ZoneId defaultZoneId = ZoneId.systemDefault();
            Instant instantE = eDate.toInstant();
            LocalDate localDateE = instantE.atZone(defaultZoneId).toLocalDate();
            String e = formatter.format(localDateE);
            if (cName == null) {
                editName.clearFocus();
                cName = editName.getText().toString();
            }
            Intent eIntent = new Intent(CourseDetail.this, MyReceiver.class);
            eIntent.putExtra("key", "Your course " + cName + " ends "+ e);
            PendingIntent senderEnd = PendingIntent.getBroadcast(CourseDetail.this, MainActivity.numAlert++, eIntent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManagerE = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManagerE.set(AlarmManager.RTC_WAKEUP, eTrigger, senderEnd);
           return true;
        }
        return super.onOptionsItemSelected(item);

    }
}