//https://www.geeksforgeeks.org/searchview-in-android-with-recyclerview/
// Used the above site to help with implementing the search functionality.
package UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
//import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;

import com.example.c196.R;

import java.util.ArrayList;
import java.util.List;

import Database.Repository;
import Entity.Term;

public class TermList extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TermAdapter termAdapter = new TermAdapter(this);
        Repository repo = new Repository(getApplication());
        buildRecyclerView(termAdapter,repo.getAllTerms());
    }
    private void buildRecyclerView(TermAdapter termAdapter,List<Term> termList) {
        RecyclerView recyclerView = findViewById(R.id.recyclerTermView);
        recyclerView.setAdapter(termAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        termAdapter.setTermItems(termList);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true);
    }
    @SuppressLint("ResourceType")
    public boolean onTermOption(Menu menu){
        getMenuInflater().inflate(R.layout.activity_term_list,menu);
        return  true;
    }
    public boolean onTermSelected(MenuItem item){
        if (item.getItemId()==android.R.id.home){
                this.finish();
                return  true;
        }
        else {
            return onTermSelected(item);
        }
    }
    // calling on create option menu
    // layout to inflate our menu file.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // below line is to get our inflater
        MenuInflater inflater = getMenuInflater();
        // inside inflater we are inflating our menu file.
        inflater.inflate(R.menu.term_search, menu);
        // below line is to get our menu item.
        MenuItem searchItem = menu.findItem(R.id.actionSearch);
        // getting search view of our item.
        SearchView searchView = (SearchView) searchItem.getActionView();
        // below line is to call set on query text listener method.
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                // inside on query text change method we are
                // calling a method to filter our recycler view.
                filter(newText);
                return false;
            }
        });
        return true;
    }
    private void filter(String text) {
        Repository repo = new Repository(getApplication());
        // creating a new array list to filter our data.
        ArrayList<Term> filteredlist = new ArrayList<Term>();
        TermAdapter adapter = new TermAdapter(this);
        // running a for loop to compare elements.
        for (Term term : repo.getAllTerms()) {
            // checking if the entered string matched with any item of our recycler view.
            if (term.getTerm_title().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(term);
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "No Term with that name found..", Toast.LENGTH_SHORT).show();
        } else {

            // at last we are passing that filtered
            // list to our adapter class.
            buildRecyclerView(adapter,filteredlist);
        }
    }
    /**
     * Navigates to a list of the courses associated with the term.
     * @param view
     */
    public void EnterCourseList(View view) {
        Intent intent = new Intent(TermList.this, CourseList.class);
        startActivity(intent);
    }

    public void EnterHome(View view) {
        Intent intent = new Intent(TermList.this,TermList.class);
        startActivity(intent);
    }

    public void EnterTermDetail(View view) {
        Intent intent = new Intent(TermList.this, TermDetail.class);
        startActivity(intent);
    }


}