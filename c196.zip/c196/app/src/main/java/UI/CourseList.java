//https://www.geeksforgeeks.org/searchview-in-android-with-recyclerview/
// Used the above site to help with implementing the search functionality.
package UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import Database.Repository;
import Entity.Course;
import Entity.Term;

public class CourseList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        RecyclerView recyclerView = findViewById(R.id.recyclerCourseView);
        Repository repo = new Repository(getApplication());
        List<Course> courseArrayList = repo.getAllCourse();
        CourseAdapter courseAdapter = new CourseAdapter(this);
        buildRecyclerView(courseAdapter,courseArrayList);
    }
    private void buildRecyclerView(CourseAdapter courseAdapter,List<Course> courseList) {
        RecyclerView recyclerView = findViewById(R.id.recyclerCourseView);
        //TermAdapter termAdapter = new TermAdapter(this);
        recyclerView.setAdapter(courseAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        courseAdapter.setCourseItems(courseList);
        // adding layout manager to our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // below line is to get our inflater
        MenuInflater inflater = getMenuInflater();
        // inside inflater we are inflating our menu file.
        inflater.inflate(R.menu.course_search, menu);
        // below line is to get our menu item.
        MenuItem searchItem = menu.findItem(R.id.courseSearch);
        // getting search view of our item.
        SearchView searchView = (SearchView) searchItem.getActionView();
        // below line is to call set on query text listener method.
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // inside on query text change method we are
                // calling a method to filter our recycler view.
                filter(newText);
                return false;
            }
        });
        return true;
    }
    private void filter(String text) {
        Repository repo = new Repository(getApplication());
        // creating a new array list to filter our data.
        ArrayList<Course> filteredlist = new ArrayList<Course>();
        CourseAdapter adapter = new CourseAdapter(this);
        // running a for loop to compare elements.
        for (Course course : repo.getAllCourse()) {
            // checking if the entered string matched with any item of our recycler view.
            if (course.getCourse_title().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(course);
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "No Course with that name found..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            buildRecyclerView(adapter,filteredlist);
        }
    }
    @SuppressLint("ResourceType")
    public boolean onCourseOption(Menu menu){
        getMenuInflater().inflate(R.layout.activity_course_list,menu);
        return  true;
    }

    public boolean onCourseSelected(MenuItem item){
        if (item.getItemId()==android.R.id.home){
            this.finish();
            return  true;
        }
        else {
            return onCourseSelected(item);
        }
    }
    public void EnterAssessmentList(View view) {
        Intent intent = new Intent(CourseList.this, AssessmentList.class);
        startActivity(intent);
    }

    public void EnterHome(View view) {
        Intent intent = new Intent(CourseList.this,CourseList.class);
        startActivity(intent);
    }

    public void EnterCourseDetail(View view) {
        Intent intent = new Intent(CourseList.this, CourseDetail.class);
        startActivity(intent);
    }
    public void detailList(View view) {
        Intent intent = new Intent(CourseList.this, CourseDetail.class);
        startActivity(intent);
    }

    public void addCourseMain(View view) {
        Intent intent = new Intent(CourseList.this, CourseDetail.class);
        startActivity(intent);
    }

}